import datetime
import numpy as np


departamentos = np.array([['A']*4, ['A']*4, ['A']*4, ['A']*4, ['A']*4, ['A']*4,
                          ['A']*4, ['A']*4, ['A']*4, ['A']*4])
compradores = []


precios = {'A': 3800, 'B': 3000, 'C': 2800, 'D': 3500}


def mostrar_estado():
    for piso, deptos in enumerate(departamentos, start=1):
        print(f'Piso {piso}: ', end='')
        for depto in deptos:
            if depto == 'X':
                print('X', end=' ')
            else:
                print('_', end=' ')
        print()


def comprar_departamento():
    piso = int(input('Ingrese el número del piso (1-10): '))
    tipo = input('Ingrese el tipo de departamento (A, B, C, D): ')
    depto = departamentos[piso - 1]

   
    if np.any(depto == 'X'):
        print('No hay departamentos disponibles en este piso.')
        return

   
    if tipo not in ['A', 'B', 'C', 'D']:
        print('Tipo de departamento inválido.')
        return

    
    if depto[ord(tipo) - ord('A')] == 'X':
        print('El departamento seleccionado no está disponible.')
        return

    run = input('Ingrese el RUN del comprador (sin guiones ni puntos): ')

   
    if not run.isdigit():
        print('RUN inválido.')
        return

    depto[ord(tipo) - ord('A')] = 'X'
    compradores.append((run, f'{tipo}{piso}'))
    print('Operación realizada correctamente.')


def mostrar_compradores():
    compradores.sort()
    for comprador in compradores:
        print(f'RUN: {comprador[0]}, Departamento: {comprador[1]}')


def mostrar_ventas_totales():
    total = np.sum([precios[tipo] for piso in departamentos for tipo in piso if tipo == 'X'])
    print(f'Las ganancias totales por concepto de ventas son: {total} UF.')


def salir():
    now = datetime.datetime.now()
    print(f'Saliendo del sistema. Fecha: {now.strftime("%Y-%m-%d %H:%M:%S")}')


def menu():
    while True:
        print('--- Inmobiliaria Casa Feliz ---')
        print('1. Comprar departamento')
        print('2. Mostrar departamentos disponibles')
        print('3. Ver listado de compradores')
        print('4. Mostrar ganancias totales')
        print('5. Salir')
        opcion = input('Ingrese una opción: ')

        if opcion == '1':
            comprar_departamento()
        elif opcion == '2':
            mostrar_estado()
        elif opcion == '3':
            mostrar_compradores()
        elif opcion == '4':
            mostrar_ventas_totales()
        elif opcion == '5':
            salir()
            break
        else:
            print('Opción inválida. Intente nuevamente.')

menu()